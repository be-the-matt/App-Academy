# tic_tac_toe-v3
An n-by-n sized tic-tac-toe game for any number of human players and computer players. Built in Ruby.

HOW TO PLAY:
1) Load game.rb
2) Initialize game: variable_name = Game.new(grid_size_number, player1_symbol: false, player2_symbol: true, etc.) hwere false indicates human player and true indicates computer player.
3) Play game: variable_name.play
