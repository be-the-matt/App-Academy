# tic_tac_toe-v2
A basic tic-tac-toe game for any number of human players and any n-by-n size grid. Built in Ruby.

HOW TO PLAY:
1) Load game.rb
2) Initialize game: variable_name = Game.new(grid_size_number, player1_symbol, player2_symbol, player3_symbol, etc.)
3) Play game: variable_name.play
