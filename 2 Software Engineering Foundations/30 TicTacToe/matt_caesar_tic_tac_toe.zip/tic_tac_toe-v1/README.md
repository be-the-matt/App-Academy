# tic_tac_toe-v1
A basic 3-by-3 tic-tac-toe game for two human players. Built in Ruby.

HOW TO PLAY:
1) Load game.rb
2) Initialize game: game_name = Game.new(:X,:O)
3) Play game: game_name.play
