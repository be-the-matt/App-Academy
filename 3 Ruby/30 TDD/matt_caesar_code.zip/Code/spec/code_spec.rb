require 'rspec'
require 'code.rb'

describe "#my_unique" do
    let(:arr) { [1, 2, 1, 3, 3] }

    it "returns unique elements in the order they first appeared" do
        expect(arr.my_unique).to eq([1, 2, 3])
    end

    it "returns a new array" do
        expect(arr.my_unique).not_to be(arr)
    end
end

describe "#two_sum" do
    let(:arr) { [-1, 0, 2, -2, 1] }
    it "returns all element index pairs that sum to 0" do
        expect(arr.two_sum).to eq( [[0, 4], [2, 3]] )
    end
end

describe "#my_transpose" do
    let(:rows) { [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8]
    ] }
    
    let(:cols) { [
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8]
    ] }

    it "converts square matrices between row-oriented and column-oriented representations" do
        expect(rows.my_transpose).to eq(cols)
    end
end

describe "#stock_picker" do
    let(:prices) { [13,5,2,8,10,11,9] }

    it "takes array of stock prices and outputs the most profitable pair of days to buy then sell" do
        expect(prices.stock_picker).to eq([2, 5])
    end
end