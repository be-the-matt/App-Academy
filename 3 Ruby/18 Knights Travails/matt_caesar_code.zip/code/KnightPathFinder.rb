require 'byebug'
require_relative 'PolyTreeNode.rb'

class KnightPathFinder

    attr_reader :considered_positions

    def initialize(pos)
        @start_pos = pos
        @considered_positions = [pos]
        @move_tree = self.build_move_tree        
    end

    def self.valid_moves(pos)
        valid_moves = []

        x_deltas = [2, -2]
        y_deltas = [1, -1]

        x_deltas.each do |x_del|
            y_deltas.each do |y_del|
                x_pos = pos[0] + x_del
                y_pos = pos[1] + y_del
                x2_pos = pos[0] + y_del
                y2_pos = pos[1] + x_del
                valid_moves << ([x_pos , y_pos]) if x_pos.between?(0,7) && y_pos.between?(0,7) #&& !@considered_positions.include?([x_pos , y_pos])
                valid_moves << ([x2_pos , y2_pos]) if x2_pos.between?(0,7) && y2_pos.between?(0,7) #&& !@considered_positions.include?([x2_pos , y2_pos])
            end
        end
        valid_moves
    end

    # def new_move_positions(pos)
    #     @valid_moves = KnightPathFinder.valid_moves(pos)
    #     @valid_moves.each { |pos| @considered_positions << pos if !@considered_positions.include?(pos) }
 
    #     @valid_moves
    # end

    def new_move_positions(pos)
        KnightPathFinder.valid_moves(pos)
            .reject { |new_pos| considered_positions.include?(new_pos) }
            .each { |new_pos| considered_positions << new_pos }
    end


    def build_move_tree
        nodes = [ PolyTreeNode.new(@start_pos) ]

        # debugger
        until nodes.empty?

            current_node = nodes.shift
            current_pos = current_node.pos

            new_move_positions(current_pos).each do |next_pos|
                next_node = PolyTreeNode.new(next_pos)
                current_node.add_child(next_node)
                nodes << next_node
            end
        end
    end

    def find_path

    end

end

kpf = KnightPathFinder.new([0,0])
# p KnightPathFinder.valid_moves([7,5])
# p kpf.considered_positions
# p kpf.new_move_positions([3,3])
p kpf.build_move_tree
p kpf